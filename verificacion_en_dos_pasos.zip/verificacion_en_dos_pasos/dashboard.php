<?php 
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style>
        /* General */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f0f0f0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        /* Contenedor principal */
        .container {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 300px;
        }

        /* Mensaje de bienvenida */
        .welcome-message h2 {
            color: #333;
            font-size: 24px;
            margin-bottom: 20px;
        }

        /* Estilo del botón de logout */
        .logout-button {
            background-color: #ff5f5f;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
        }

        .logout-button:hover {
            background-color: #ff2d2d;
        }

        .logout-button:focus {
            outline: none;
        }

        /* Diseño responsivo para pantallas pequeñas */
        @media (max-width: 500px) {
            .container {
                width: 90%;
                padding: 20px;
            }

            .welcome-message h2 {
                font-size: 20px;
            }

            .logout-button {
                font-size: 14px;
                padding: 8px 16px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="welcome-message">
            <h2>Bienvenido, <?php echo htmlspecialchars($_SESSION['user']); ?>!</h2>
        </div>

        <!-- Botón para cerrar sesión -->
        <form method="post">
            <button type="submit" name="logout" class="logout-button">Cerrar sesión</button>
        </form>
    </div>

    <?php
    // Cerrar sesión
    if (isset($_POST['logout'])) {
        session_destroy();  // Destruir sesión
        header("Location: index.php");  // Redirigir al login
        exit;
    }
    ?>
</body>
</html>
