<?php
require 'db.php';

$msg = '';
$questions = [
    "¿Cuál es el nombre de tu mascota?",
    "¿En qué ciudad naciste?",
    "¿Cuál es el nombre de tu madre?",
    "¿Cuál es tu color favorito?",
    "¿En qué escuela estudiaste?"
];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $q1 = $_POST['question1'];
    $a1 = $_POST['answer1'];
    $q2 = $_POST['question2'];
    $a2 = $_POST['answer2'];

    $stmt = $conn->prepare("SELECT id FROM users WHERE username=?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        $msg = "El nombre de usuario ya existe.";
    } else {
        $stmt = $conn->prepare("INSERT INTO users (username, password, question1, answer1, question2, answer2)
            VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $username, $password, $q1, $a1, $q2, $a2);
        if ($stmt->execute()) {
            $msg = "Usuario registrado correctamente.";
            // Redirigir al login después de un registro exitoso
            header("Location: index.php");
            exit; // Termina el script para evitar que se ejecute cualquier otra cosa
        } else {
            $msg = "Error al registrar.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
    <style>
        /* General */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f0f0f0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        /* Contenedor principal */
        .container {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 300px;
        }

        /* Mensaje de error o éxito */
        .msg {
            color: red;
            margin-bottom: 20px;
        }

        /* Estilo del formulario */
        form input, form select {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        /* Estilo del botón */
        button {
            background-color: #5fafff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #428bc4;
        }

        button:focus {
            outline: none;
        }

        /* Diseño responsivo */
        @media (max-width: 500px) {
            .container {
                width: 90%;
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Registro</h2>
        <form method="post">
            Usuario: <input type="text" name="username" required><br>
            Contraseña: <input type="password" name="password" required><br>
            Pregunta 1:
            <select name="question1" required>
                <?php foreach($questions as $q) echo "<option>$q</option>"; ?>
            </select><br>
            Respuesta 1: <input type="text" name="answer1" required><br>
            Pregunta 2:
            <select name="question2" required>
                <?php foreach($questions as $q) echo "<option>$q</option>"; ?>
            </select><br>
            Respuesta 2: <input type="text" name="answer2" required><br>
            <button type="submit">Registrar</button>
        </form>
        <p class="msg"><?php echo $msg; ?></p>
    </div>
</body>
</html>
