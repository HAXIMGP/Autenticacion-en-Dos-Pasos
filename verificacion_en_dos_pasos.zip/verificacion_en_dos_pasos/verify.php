<?php
session_start();
require 'db.php';

if (!isset($_SESSION['verify_user'])) {
    header("Location: index.php");
    exit;
}

$msg = '';
$username = $_SESSION['verify_user'];
$stmt = $conn->prepare("SELECT * FROM users WHERE username=?");
$stmt->bind_param("s", $username);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if ($_POST['answer1'] === $user['answer1'] && $_POST['answer2'] === $user['answer2']) {
        $_SESSION['user'] = $username;
        unset($_SESSION['verify_user']);
        header("Location: dashboard.php");
        exit;
    } else {
        $msg = "Respuestas incorrectas.";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verificación</title>
    <style>
        /* General */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f0f0f0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        /* Contenedor principal */
        .container {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 300px;
        }

        /* Mensaje de error */
        .msg {
            color: red;
            margin-bottom: 20px;
        }

        /* Estilo del formulario */
        form input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        /* Estilo del botón */
        button {
            background-color: #5fafff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #428bc4;
        }

        button:focus {
            outline: none;
        }

        /* Diseño responsivo */
        @media (max-width: 500px) {
            .container {
                width: 90%;
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Verifica tu identidad</h2>
        <form method="post">
            <p><?php echo $user['question1']; ?></p>
            <input type="text" name="answer1" required><br>
            <p><?php echo $user['question2']; ?></p>
            <input type="text" name="answer2" required><br>
            <button type="submit">Verificar</button>
        </form>
        <p class="msg"><?php echo $msg; ?></p>
    </div>
</body>
</html>
