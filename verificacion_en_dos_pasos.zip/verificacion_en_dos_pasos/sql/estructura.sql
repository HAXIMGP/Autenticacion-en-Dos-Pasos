CREATE DATABASE IF NOT EXISTS auth_demo;
USE auth_demo;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    question1 VARCHAR(255),
    answer1 VARCHAR(255),
    question2 VARCHAR(255),
    answer2 VARCHAR(255)
);